\---  
name: generating-icon-systems  
description: Use when generating or refining a coherent family of filled or linear UI icons from text briefs, object references, photos, or an existing icon direction.  
\---

# Generating Icon Systems

Generate icons as one visual family, not as unrelated individual images.

## Core Contract

Separate every request into:

1. **Semantic specification:** meaning, subjects, count, order, layout, must-keep features, removable details, and ambiguity risks.
2. **Rendering profile:** geometry, palette, material, opacity, lighting, stroke, detail density, shadow, highlight, and negative constraints.

Changing subjects must not silently change the profile. Restyling must not silently change count, order, labels, or meaning.

## Route the Task

- For a photo or real object, read [references/workflow.md](references/workflow.md) before choosing a profile. Abstract the object; do not trace photographic noise.
- For filled, gradient, colorful, or lightly dimensional icons, read [references/filled-icon-profile.md](references/filled-icon-profile.md).
- For outline, stroked, monochrome, 24×24, or specified-stroke icons, read [references/linear-icon-profile.md](references/linear-icon-profile.md).
- When choosing a company profile or explaining the Lucide/Radix comparison, read [references/design-system-evidence.md](references/design-system-evidence.md). The company profile is our adaptation, not an official Lucide or Radix specification.
- To construct a reusable generation prompt, read [references/prompt-templates.md](references/prompt-templates.md).
- Before delivery or iteration, read [references/quality-gates.md](references/quality-gates.md).
- When visual calibration helps, read [references/examples.md](references/examples.md). Examples show mechanisms, not mandatory subjects or pixel templates.

Do not combine filled material rules with linear stroke rules unless the user explicitly requests a hybrid family.

## Working Rules

1. Lock content invariants before styling.
2. Define shared family rules before expanding individual subjects.
3. Add only semantic or material-specific detail.
4. Generate comparable icons together when family consistency matters.
5. Review content correctness before visual polish.
6. Iterate one variable at a time; do not change composition, palette, material, and detail simultaneously.
7. Treat image-generation output as a visual proposal. For numeric stroke or grid requirements, construct and inspect individual SVG assets.

## Delivery

Return the chosen profile, normalized subject list, final prompt or asset, and a short QA result. State whether the output is a visual preview or a production-ready vector. Never claim exact SVG geometry or stroke precision from a raster preview.

This skill does not generate mobile launcher-icon size packages; use a launcher-icon export workflow for that task.
