# Prompt Templates

Build prompts from two layers:

- **Fixed family rules:** chosen profile, geometry, palette, material, lighting, detail density, layout logic, and negative constraints.
- **Variable subject rules:** icon count, order, semantic features, justified material exceptions, and exact labels.

Do not encode one project's subjects as universal rules.

## Filled Family Template

```text
Use case: stylized-concept
Asset type: coherent filled UI icon family

Primary request:
Create exactly {count} icons arranged as {layout}.

Exact subjects and order:
{numbered subjects with meaning, must-keep features, material, and overlap relationships}

Family profile:
Use a clear-vivid-matte 2.5D filled style. Keep silhouettes simple, rounded,
and UI-readable. Use medium-high saturation, medium local contrast, matte
surfaces, shallow depth, and consistent upper-left lighting.

Color and volume:
Use 2–4 coordinated color planes per icon: a clean warm highlight plane,
a vivid main face, and a controlled darker structural plane. Keep opaque
solids visually 92–100% opaque. Use transparency only for physically
plausible glass, screens, windows, or thin material edges.

Highlight and depth limits:
Keep edge depth visually shallow, about 4–8% of subject size. Keep obvious
highlights below about 5–8% of visible icon area. Use no continuous white
rim lights, double bright edges, repeated highlight rings, or mirror strips.
Use short diffuse shadows at about 8–12% visual opacity.

Consistency:
Keep icon scale, optical weight, perspective, corner language, light
direction, detail density, shadow softness, and spacing consistent.

Composition:
{canvas ratio and grid}. Pure white or requested background. Each icon is
centered in an invisible equal-size cell with generous breathing room.

Content invariants:
Preserve the exact count, order, subjects, and labels. Do not add objects.

Avoid:
washed-out pastel color, global transparency, milky fog, glossy plastic,
thick bevels, strong ambient occlusion, metallic shine, clay style,
photorealistic 3D, black-heavy outlines, long dark shadows, scenery,
captions, logos, and watermarks.
```

Replace the warm palette language with the requested company palette while preserving contrast and material logic.

## Linear Family Template

```text
Use case: logo-brand
Asset type: coherent linear UI icon family

Primary request:
Create exactly {count} outline icons arranged as {layout}.

Exact subjects and order:
{numbered subjects with meaning and must-keep recognition features}

Family profile:
Use {company-24-light | lucide-24 | radix-15}. Unless the user specifies
otherwise, choose company-24-light: independent 24×24 artboards, 1.5px
centered strokes, round caps and joins, no fill, at least 1.5px visible
padding and 2px gaps between detached elements. Keep one profile for the
entire family.

Geometry:
Use one main silhouette plus at most one semantic modifier and no more than
three identifying features. Target 2–5 independent visual elements per icon.
Allow 6–7 only when necessary for recognition; return 8 or more to abstraction.
Use consistent radii, clean negative space, and optical centering. Delete
details that will collapse at target size.

Consistency:
Keep live area, apparent stroke weight, perspective, corner language,
detail density, padding, and visual center consistent.

Composition:
{canvas ratio and grid}. Pure white or requested background. No visible
cell borders or dividers.

Content invariants:
Preserve the exact count, order, subjects, and labels. Do not add objects.

Avoid:
filled gradients, material shading, 2.5D depth, variable stroke widths,
inconsistent caps or joins, photographic tracing, excess detail, captions,
logos, watermarks, and decorative backgrounds.
```

For exact numeric output, ask for one SVG per icon, not a composite raster.
Inspect the SVG attributes and render each icon at 16, 20, and 24px. For
`radix-15`, inspect at 15px and do not force a stroked 24px construction.

## Targeted Iteration Template

```text
Change only {one variable}.

Keep unchanged:
{count, order, subjects, layout, profile, palette, perspective, materials,
lighting, scale, spacing, and any other invariants}

Correction:
{specific observable adjustment}

Avoid:
{failure mode caused by the previous output}
```

Use targeted iteration after the first draft. Rewriting the whole prompt makes it harder to identify which rule improved or damaged the result.
