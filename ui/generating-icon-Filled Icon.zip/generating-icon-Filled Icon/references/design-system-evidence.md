# Design-System Evidence and Adaptation

These are observations from the Lucide and Radix source libraries, used to inform this skill. They do not make the company profile an official extension of either library.

## Lucide

At the research snapshot, the official repository contained 1,756 SVG icons. The icon design guide specifies a 24×24 canvas, 2px centered stroke, round caps and joins, at least 1px visible padding, and at least 2px between detached parts. The median icon had 4 independent SVG elements; the 75th percentile had 5, and the 90th had 7. Common objects were compact: `search` and `tag` used 2 elements, `shopping-cart` 3, `gift` 4, and `truck` 5.

Use the distribution as a simplification heuristic, not a universal prohibition: SVG element count is only a rough proxy for perceptual complexity.

## Radix

The research snapshot contained 332 published 15×15 SVG icons. Most published files used a filled `currentColor` outline rather than a simple stroke. Editable Figma sources often used about 1px strokes with local optical adjustments. A long path command list may describe one expanded outline and should not be mistaken for excessive visible detail.

Design at the actual 15px size when matching Radix. Review local widths, openings, endpoints, and pixel alignment; scaling down a 24px SVG is insufficient.

## Our Company 24 Light Profile

The default 24×24, 1.5px centered-stroke profile combines Lucide-like spatial discipline with a lighter visual weight requested for this project. The 2–5 perceptual-element target and optical family checks help prevent dense, heavy results. It is a project decision, not a number derived by averaging the two libraries.

Do not copy library icon paths into a company asset by default. Reuse construction and review principles, then draw the needed business metaphor.

## Sources

- [Lucide icon design guide](https://github.com/lucide-icons/lucide/blob/main/docs/contribute/icon-design-guide.md)
- [Lucide icon library](https://lucide.dev/icons/)
- [Radix icon library](https://www.radix-ui.com/icons)
- [Radix source repository](https://github.com/radix-ui/icons)
- [Radix Icons Community Figma file](https://www.figma.com/design/QHqz2Tck7Mvdfw5ZGdbaa5/Radix-Icons--Community-)

Research snapshots: Lucide `1d7da164bbaf684159accdfd3d568d82b87d54bd`; Radix `112af91ad275a63c3a29b0da2588342af74ef9bf`.
