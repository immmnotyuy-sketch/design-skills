# Filled Profile: Clear Vivid Matte 2.5D

Use this profile for colorful filled icons that need restrained depth without glossy toy rendering.

## Core Interpretation

“Clear” or “translucent” means clean color, readable material, and controlled light. It does **not** mean pale color, global low opacity, low contrast, or a milky overlay.

Opaque solids—envelopes, shields, gifts, walls, folders, and vehicle bodies—remain visually 92–100% opaque. Transparency belongs only to physically plausible materials such as glass, cup lids, screens, windows, and thin paper edges.

## Calibrated Controls

| Control | Target |
| --- | --- |
| Saturation | Medium-high, clean rather than neon |
| Local contrast | Medium; planes remain visibly distinct |
| Color planes | 2–4 coordinated values per icon |
| Edge depth | About 4–8% of subject size |
| Dark structural plane | About 15–25% without dominance |
| Obvious highlight area | No more than about 5–8% |
| Shadow visual opacity | About 8–12%, short and diffuse |
| Surface | Matte or soft gradient, not mirrored |
| Light direction | Upper-left unless another direction is specified |

These are visual calibration ranges, not requirements to perform pixel-level measurement on an image-generation draft.

## Color Logic

Use color-plane contrast to describe volume:

```text
orange highlight → coral/red main face → controlled deep-red plane
```

Starter palette for an orange-red family:

```yaml
light_peach: "#FFD0BE"
highlight_orange: "#FF9A5C"
base_orange: "#FF7133"
vivid_coral: "#FF4B36"
clear_red: "#EF3035"
deep_red: "#D92530"
accent_yellow: "#FFD338"
accent_gold: "#FFB814"
```

Treat this as a replaceable company palette, not a universal brand requirement.

## Highlight Discipline

- Each major opaque block gets at most one broad, weak highlight plane.
- Do not create continuous white rim lights, double bright edges, repeated highlight rings, or mirror strips.
- Small seals, ribbons, and bevel edges should rely on color-value differences before adding white shine.
- Transparent glass may have one narrow reflection; do not spread that treatment to opaque bodies.
- If the result looks oily, reduce highlights and specular reflections first. Do not immediately desaturate the whole palette.

## Depth Discipline

- Keep the silhouette predominantly flat or only slightly angled.
- Use shallow overlap, lid thickness, paper curl, or side planes only when they clarify the object.
- Prefer matte gradients and plane separation over thick bevels.
- Keep shadows close to the object. Avoid long cast shadows, strong ambient occlusion, clay inflation, metallic gloss, or miniature-scene perspective.

## Material Logic

| Material | Treatment |
| --- | --- |
| Painted solid | Opaque, matte, 2–3 color planes |
| Glass/window | Transparent or translucent with one restrained reflection |
| Paper | Near-white or colored, thin edge, faint fold/contact shadow |
| Fabric/ribbon | Opaque, curved color planes, no metallic shine |
| Coin/accent metal | Bright yellow/gold; keep reflection restrained unless realistic metal is requested |

## Family Consistency

Keep scale, optical weight, perspective, corner language, light direction, detail density, shadow softness, and negative space consistent. A subject may use different materials, but it should not look as if it came from another rendering system.

## Avoid

- washed-out pastel color;
- global transparency or fog;
- dark crimson dominating every surface;
- glossy plastic-toy rendering;
- thick bevels or inflated edges;
- black outlines unless requested;
- neon color, clay style, metallic finish, or photorealistic 3D;
- decorative scenery, labels, logos, or extra objects not in the brief.
