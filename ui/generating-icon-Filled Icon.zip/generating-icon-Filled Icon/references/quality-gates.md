# Quality Gates

Review content before visual style. A beautiful image with the wrong subjects is a failed icon set.

## Pass 1: Content Integrity

Check:

- exact icon count;
- exact order and grid positions;
- exact labels and language, if labels are requested;
- every subject is present once;
- no invented standalone objects;
- the intended meaning is recognizable;
- must-keep semantic features survived abstraction;
- no logo, watermark, caption, or scenery was added.

If this pass fails, correct content only. Preserve the rendering profile.

## Pass 2: Family Consistency

Compare the whole family side by side:

- subject scale and live area;
- optical weight;
- perspective and viewing angle;
- corner and terminal language;
- light direction;
- color saturation and local contrast;
- detail density;
- shadow strength or stroke weight;
- spacing and optical centering.

An individually polished icon still fails if it looks as if it belongs to another family.

## Filled Profile Checks

- Opaque subjects remain opaque; transparency appears only on plausible materials.
- The palette is vivid and clean, not pale, foggy, neon, or dark-dominated.
- Major color planes remain distinct without black outlines.
- Edge depth is shallow rather than inflated.
- Dark planes support structure without dominating.
- Highlights are restrained; there are no continuous white rim lights or repeated shine rings.
- Surfaces read as matte or softly graded, not glossy plastic.
- Shadows are short, diffuse, and consistent.

When a result looks oily, reduce specular highlights before reducing saturation. When it looks pale, restore solid opacity and color-plane contrast before adding darker shadows.

## Linear Profile Checks

- Default company profile uses 24×24, 1.5px centered strokes, at least 1.5px visible padding, and at least 2px between detached parts; user-selected compatibility profiles supersede these numbers.
- Each icon has one dominant silhouette, at most one modifier, and normally 2–5 perceptual elements. Review 6–7 for semantic necessity; simplify 8 or more.
- There are no duplicated contours, decorative micro-lines, or realistic parts that do not improve recognition.
- One family-consistent stroke width is used.
- Caps and joins match the profile.
- Counters and gaps remain open at target size.
- Tiny segments or double strokes do not create dark knots.
- Apparent weight, not only numeric stroke width, is consistent.
- Icons render clearly at actual target sizes.
- Production SVG uses the required viewBox, color behavior, and fill/stroke model.

## Semantic Blind Check

When practical, show the final small icons without names and ask what each most likely means. Record the top interpretations. If a critical icon is repeatedly mistaken for another concept, restore a recognition feature instead of adding decoration.

## Iteration Rule

Adjust one category at a time:

1. content or metaphor;
2. composition and scale;
3. color and contrast;
4. material and opacity;
5. highlight and shadow;
6. detail density.

If the same issue survives two iterations, return to the source brief or reference and revise the relevant profile rule rather than stacking more prompt adjectives.

## Delivery Statement

State whether the deliverable is:

- a raster visual preview;
- a vector concept needing geometric cleanup;
- a validated production SVG;
- an exported icon-library asset.

Do not describe a raster preview as exact 1.5px or 2px production geometry.
