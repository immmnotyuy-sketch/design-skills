# Linear Icon Profile

Use this profile for outline, stroked, monochrome, small-size, or explicit-grid icon families.

## Default: Company 24 Light

```yaml
artboard: "24×24"
stroke_width: "1.5px, centered"
linecap: "round"
linejoin: "round"
visible_padding_min: "1.5px"
detached_element_gap_min: "2px"
color: "currentColor; preview may use black"
fill: "none"
```

This is a proposed light company style, not an official Lucide or Radix profile. Honor a user-specified stroke or grid instead of silently replacing it.

## Compatibility Profiles

- `lucide-24`: 24×24, 2px centered stroke, round caps and joins. Use when the family must sit alongside Lucide or the user explicitly requests 2px.
- `radix-15`: design and inspect at 15×15; approximately 1px visual weight with local optical corrections. Published icons commonly use filled outline paths. Do not obtain this mode by mechanically shrinking a 24px master.

Keep one profile per family. See [design-system-evidence.md](design-system-evidence.md) for source and interpretation.

## Semantic Complexity Budget

- Use one main silhouette and at most one semantic modifier.
- Keep at most three recognition features; omit real-world components that do not aid recognition.
- Aim for 2–5 independent visual elements. Allow 6–7 only when simplification creates ambiguity. At 8 or more, return to abstraction or request a review.
- Use at most two decorative/internal lines by default; a list or ticket may need up to three short lines. Avoid duplicate symbols or repeated outlines that express the same meaning.
- Count perceptual parts, not SVG path commands: a Radix filled-outline path can encode several visual parts.

## Geometry

- Use a small number of paths and clear geometric primitives.
- Keep similar radii, terminal lengths, gaps, and detail density.
- Align optically, not only mathematically. Asymmetric subjects may need visual compensation.
- Avoid tiny segments, cramped intersections, accidental double strokes, and details that collapse at target size.
- Maintain negative space at least comparable to the stroke so counters remain open.
- Keep detached elements at least 2px apart in the default company profile and keep visible strokes inside its 1.5px safe edge.

## Family Consistency

Define once:

- stroke width;
- caps and joins;
- corner language;
- live area and padding;
- perspective;
- level of detail;
- use of filled accents;
- directionality conventions.

Do not scale a large detailed drawing down and assume it becomes a small icon. Simplify for the target grid.

## Preview and QA

Render at the actual target sizes, commonly 16, 20, and 24 pixels. Check:

- apparent stroke weight;
- crispness and antialiasing;
- open counters and gaps;
- optical centering;
- family comparison on light and dark UI backgrounds;
- recognizability without labels.

## SVG Delivery

For a company or Lucide-compatible web master, prefer `viewBox="0 0 24 24"`, `fill="none"`, and `stroke="currentColor"`; set the selected stroke width and round caps/joins explicitly. For Radix-compatible output, use its 15×15 filled-outline construction when appropriate. Remove filters, gradients, raster images, and unnecessary transforms. Validate parsing and render the exported SVG before calling it production-ready.

## Avoid

- filled gradients or 2.5D material shading;
- variable stroke widths inside one family;
- inconsistent caps, joins, or corner radii;
- photographic tracing;
- excess path points and decorative detail;
- judging only a large preview.
