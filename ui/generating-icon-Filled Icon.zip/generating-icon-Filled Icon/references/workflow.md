# Icon Family Workflow

Use this workflow when the input is a text brief, photograph, object reference, sketch, screenshot, or existing icon direction.

## 1. Normalize the Brief

Lock the following before discussing style:

```yaml
purpose: "Where the icons will be used"
subjects:
  - name: "Semantic name"
    meaning: "What users should understand"
    must_keep: ["recognition features"]
    optional: ["helpful details"]
    remove: ["noise or decoration"]
count: 0
order: []
layout: "grid or individual assets"
labels: "exact text or none"
output: "preview raster, SVG concept, or production vector"
```

If purpose or meaning changes the icon metaphor, request that information. Do not infer that the photographed object and the intended UI concept are identical.

## 2. Abstract Photo or Object Inputs

Do not trace pixels. Produce an **Object DNA** description first:

```yaml
identity: "cup"
intended_meaning: "food-court drinks"
silhouette: "tapered rounded cup"
must_keep: ["domed lid", "straw", "lower pearls"]
optional: ["sleeve"]
remove: ["logo", "reflection", "table shadow", "texture"]
base_shapes: ["trapezoid", "dome", "line", "circles"]
preferred_view: "front with slight depth"
ambiguity_risks: ["without pearls it may read as a generic drink"]
```

Keep only the recognition features that survive at the target size: up to three for the default linear profile, and usually two to four for a filled illustration. Remove incidental texture, lighting, branding, reflections, and background contours. The output should preserve semantic identity, not photographic fidelity.

## 3. Choose One Profile

Choose the filled profile for color planes, materials, gradients, or light dimensionality. Choose the linear profile for strokes, outline systems, small UI sizes, or explicit grid/stroke requirements.

Do not mix them because a previous example happened to use the other mode.

## 4. Define Family Invariants

Set shared rules before writing individual prompts:

- canvas or preview layout;
- live area and scale;
- optical weight;
- perspective;
- corner language;
- light direction;
- palette and contrast;
- detail density;
- material and opacity logic;
- shadow or stroke system;
- prohibited effects.

Allow an exception only when the subject's material or meaning requires it, and state the reason.

## 5. Expand Subjects

For every icon, add only:

- recognition features;
- function-specific symbols;
- physically plausible material details;
- necessary front/back relationships.

Avoid decorative detail that does not improve recognition. Keep the family at a similar level of complexity.

## 6. Generate and Review

Generate the family together when side-by-side comparison matters. Review in this order:

1. count, order, labels, and meaning;
2. recognizability and ambiguity;
3. family consistency;
4. profile-specific color, material, stroke, highlight, and shadow rules.

## 7. Iterate One Variable

Make one targeted change per iteration—for example saturation, highlight amount, depth, subject detail, or spacing. Preserve all other invariants. If the same criticism recurs twice, return to the reference or brief instead of adding more adjectives.

## Output Boundary

A generated PNG is a visual direction, not proof of exact stroke or vector geometry. For production vectors, rebuild or validate SVG geometry, render at target sizes, and compare the whole family again.
