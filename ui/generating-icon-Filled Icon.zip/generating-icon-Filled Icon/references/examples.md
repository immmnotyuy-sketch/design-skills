# Example Calibration

These project-owned images are generation experiments, not approved production assets. Use them to discuss family mechanisms and identify corrections. They are not mandatory subjects, palettes, or pixel templates.

## Filled: Clear Vivid Matte 2.5D

![Five orange-red filled icons showing a parcel station, red envelope, gift box, apartment, and taxi](../assets/examples/filled-clear-vivid-matte.png)

What to take from this example:

- medium-high saturation without neon color;
- clear orange, coral-red, and deep-red structural planes;
- matte rather than mirrored opaque surfaces;
- shallow depth and short soft shadows;
- transparent windows limited to materials that should be transparent;
- consistent light direction, scale, perspective, and detail density.

What not to copy literally:

- the orange-red palette when another brand palette is requested;
- the five subjects or 3-over-2 layout;
- building and vehicle perspective when the target family is front-facing;
- any individual contour as a universal shape.

Review note: the station's many locker doors, the building's windows and balconies, and the taxi's surface details make this preview denser than a small navigation icon should be. Its prominent bevels also approach a toy-like look. A production pass should simplify these subjects and reduce edge shine while keeping the clean color planes.

## Linear: Ecommerce Family

![Nine monochrome ecommerce outline icons in a three-by-three grid](../assets/examples/linear-ecommerce.png)

What to take from this example:

- one apparent stroke weight across different metaphors;
- repeated round caps, joins, and corner language;
- consistent cell size, live area, and spacing;
- simplified semantic combinations such as list-plus-heart or bubble-plus-star;
- recognizability without captions.

What still requires production work:

- remove the shopping-cart basket grid, truck speed lines, and repeated card/list details where they do not improve recognition;
- compare all nine icons against the `company-24-light` 2–5 perceptual-element target;
- rebuild or inspect SVG paths;
- verify the exact stroke width numerically;
- render at 16, 20, and 24 pixels;
- correct optical centering and gaps at actual size;
- validate `currentColor`, viewBox, and fill/stroke behavior.
