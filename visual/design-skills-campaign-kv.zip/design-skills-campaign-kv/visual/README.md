# 视觉设计

收录品牌、字体、色彩、海报和视觉表达相关的 skill。

每个 skill 使用独立文件夹，并以 `SKILL.md` 作为入口。

## Skills

- [Campaign Key Visuals](./generating-campaign-key-visuals/)：将活动主视觉、海报、电商促销图和高密度营销主图拆分为内容、层级、渲染与交付四个契约，并控制文字、信息卡片、尺寸与来源说明。

[返回分类导航](../README.md)
