---
name: generating-campaign-key-visuals
description: Use when creating or refining campaign key visuals, event posters, e-commerce promotional artwork, or dense marketing heroes where composition hierarchy, embedded text, information cards, and delivery dimensions must remain controlled.
---

# Generating Campaign Key Visuals

Define four contracts before generation:

- **Content:** required objects, exact text, blank regions, forbidden elements, count, and order.
- **Hierarchy:** title, focal subject, motion path, depth layers, supporting world, background, and information modules.
- **Rendering:** palette, material, lighting, style, density, and finish.
- **Delivery:** requested and actual aspect ratio and dimensions, format, source-raster dimensions, raster-upscale status, and canvas/layout recomposition status.

Rendering changes must not silently alter the content, hierarchy, or delivery contracts. Inspect the actual output instead of trusting the prompt, and pass content QA before judging style.

## References

1. Start with [workflow.md](references/workflow.md) to normalize the brief and sequence decisions.
2. Use [composition-brief.md](references/composition-brief.md) to lock a dense visual's hierarchy and spatial skeleton.
3. Read [text-and-typography.md](references/text-and-typography.md) whenever text, blank cards, or local fonts are involved.
4. Assemble generation instructions with [prompt-template.md](references/prompt-template.md).
5. Review every candidate with [quality-gates.md](references/quality-gates.md).
6. Before handoff, follow [delivery-and-provenance.md](references/delivery-and-provenance.md).
