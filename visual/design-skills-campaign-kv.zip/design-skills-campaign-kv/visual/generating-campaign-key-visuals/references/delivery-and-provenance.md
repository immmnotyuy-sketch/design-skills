# Delivery and Provenance

Verify the final file rather than inferring delivery properties from the prompt, filename, or requested preset.

## Required record

- Exact output pixel dimensions: width × height.
- Actual aspect ratio, simplified when useful.
- File format.
- Color mode when relevant to the handoff.
- Source-raster dimensions.
- Raster upscale: yes/no, with method when relevant.
- Canvas or layout recomposition: yes/no, with crop, padding, extension, or rebuild noted.
- Typography composition: direct render/post-composition/no text.
- Any retouching or format conversion applied.

These fields are orthogonal. A final-size recomposed canvas may still contain raster art enlarged from a smaller source. Recomposition does not make that embedded art native-detail. “Native-detail” applies when the relevant raster content originated at or above the delivered sampling density; exporting or placing a smaller source on a final-size canvas does not create native detail.

Preserve the originating render and version each derived output. Never describe a long-edge upscale as native 4K. “4K” is ambiguous: UHD is commonly 3840×2160, while DCI 4K is commonly 4096×2160; portrait and non-16:9 work should be reported by exact dimensions and ratio rather than by the label alone.

## Handoff checklist

- [ ] Open the delivered file and confirm it is readable.
- [ ] Record exact output dimensions, ratio, and format.
- [ ] Record source-raster dimensions and raster-upscale status.
- [ ] Record canvas/layout recomposition and typography-composition status.
- [ ] Confirm content and style gates passed on the final version.
- [ ] Preserve the originating render and label derived versions clearly.
- [ ] State crops, padding, recomposition, typography, retouching, and upscaling without overstating quality.
