# Composition Brief

Object count alone is not composition. A dense campaign key visual needs a dominant hierarchy, a readable route through the scene, and controlled transitions between depth layers.

## Skeleton

- **Canvas:** orientation, requested aspect ratio, working dimensions, crop-safe area, and edge behavior.
- **Title:** location, scale, reading order, contrast, and relationship to the subject.
- **Focal subject:** dominant subject, gesture or orientation, scale, and overlap rules.
- **Motion path:** circular, diagonal, spiral, or directional flow connecting the title, subject, and supporting elements.
- **Foreground depth:** framing elements, partial crops, atmospheric effects, and overlaps that create entry into the scene.
- **Supporting world:** grouped secondary objects with assigned roles and relative prominence, not a flat checklist.
- **Background context:** setting, horizon or structural anchors, and the level of detail needed to support rather than compete.
- **Information modules:** card count, position, size, reading order, supplied content, and regions that must remain blank.
- **Intentional negative space:** protected breathing room for legibility, later typography, or visual pacing.

## Reusable template

```markdown
Canvas: [orientation] · [ratio] · [dimensions] · [crop-safe notes]
Title: [exact copy or reserved region] · [position/scale/contrast]
Focal subject: [subject] · [pose/orientation] · [dominance]
Motion path: [shape/direction] · [entry → focal point → exit]
Foreground depth: [elements/effects/overlaps]
Supporting world: [group A + role] · [group B + role]
Background context: [setting/anchors/detail level]
Information modules: [count/order/content/blank interiors]
Negative space: [location/purpose/protection]
```

Lock this skeleton before expanding texture, particles, props, or other decorative detail. Rendering changes may refine appearance but must not quietly move, add, remove, or reprioritize contracted elements.
