# Text and Typography

## Choose the production path

Use direct rendering only for short, inspectable text when every required glyph can be checked at useful zoom. Use post-composition for longer copy, multiple modules, small text, critical wording, or any script the generator reproduces unreliably. Reserve a clean region with the required contrast and geometry before generation.

Compare every glyph, punctuation mark, specified line break, and reading-order requirement against the supplied copy. Visual similarity is not textual accuracy.

When copy has not been supplied, information cards must remain genuinely blank. Do not add labels, placeholder lines, icons, fake UI, watermarks, signatures, pseudo-text, or invented copy.

## Prepare local fonts

1. Identify the intended font files and inspect family name, style, format, and metadata.
2. Confirm the application can see the exact family and weight needed for composition.
3. When installation is requested, prefer user-scoped installation unless the user explicitly needs a system-wide setup.
4. Restart the design or rendering application after installation if it does not refresh its font list automatically.

If macOS privacy controls deny access, stop repeated command-line attempts. Use a user-authorized Finder operation, or ask the user to move only the intended files into an accessible location. Never bypass security with elevated privileges, broad permission changes, or privacy-setting changes.

## Rights and repository safety

Installed, bundled, or downloaded does not prove commercial-use or redistribution rights. Verify the relevant license separately for use, embedding, modification, and redistribution. Never commit font binaries to the skill repository. Converting text to outlines or rasterizing it is not a license workaround; those techniques do not create rights the license did not grant.
