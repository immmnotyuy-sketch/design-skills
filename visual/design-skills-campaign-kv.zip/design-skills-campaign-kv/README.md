# Design Skills · 设计技能库

整理与沉淀 UI、UX、视觉和视频领域可复用的设计方法、工作流程与实践经验。

## 分类导航

| 分类 | 目录 | 内容方向 |
| --- | --- | --- |
| UI · 界面设计 | [ui](./ui/) | 页面布局、组件、设计系统与界面实现 |
| UX · 用户体验 | [ux](./ux/) | 用户研究、信息架构、用户流程与体验评估 |
| 视觉设计 | [visual](./visual/) | 品牌、字体、色彩、海报与视觉表达 |
| 视频创作 | [video](./video/) | 脚本、分镜、运镜、剪辑节奏与视频动效 |

## 目录结构

```text
design-skills/
├── README.md
├── ui/
│   └── README.md
├── ux/
│   └── README.md
├── visual/
│   └── README.md
└── video/
    └── README.md
```

## Skill 的组织方式

每个 skill 使用独立文件夹，放在最相关的分类下：

```text
分类/skill-name/
├── SKILL.md       # 使用场景、方法、步骤与输出要求
├── references/    # 按需添加的参考资料
└── examples/      # 按需添加的示例
```

文件夹名称使用小写英文，多个单词用连字符连接。跨领域的 skill 选择一个主要分类，并在说明中标注其他适用领域。

## 已收录 Skill

- 视觉设计：[Campaign Key Visuals](./visual/generating-campaign-key-visuals/) — 控制活动主视觉、海报与营销主图的构图层级、文字处理和交付规格。
