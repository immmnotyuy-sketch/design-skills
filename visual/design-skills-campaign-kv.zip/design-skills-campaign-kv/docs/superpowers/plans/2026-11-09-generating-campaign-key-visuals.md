# Generating Campaign Key Visuals Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Publish a validated visual-design skill for producing compositionally controlled, text-safe, and transparently delivered campaign key visuals.

**Architecture:** Keep `SKILL.md` short and route composition, typography, prompting, review, and delivery detail into focused references. Treat content, hierarchy, rendering, and delivery as separate contracts, then verify them through behavioral cases and structural validation.

**Tech Stack:** Markdown, YAML, Git, Codex `skill-creator` validation scripts.

---

## File Map

- `visual/generating-campaign-key-visuals/SKILL.md`: discovery, routing, shared invariants, and delivery contract.
- `visual/generating-campaign-key-visuals/agents/openai.yaml`: Codex UI metadata.
- `visual/generating-campaign-key-visuals/references/workflow.md`: end-to-end decision flow.
- `visual/generating-campaign-key-visuals/references/composition-brief.md`: hierarchy and motion-path specification.
- `visual/generating-campaign-key-visuals/references/text-and-typography.md`: direct-render versus post-composition text and local-font boundaries.
- `visual/generating-campaign-key-visuals/references/prompt-template.md`: reusable prompt slots.
- `visual/generating-campaign-key-visuals/references/quality-gates.md`: content-first and style-second QA.
- `visual/generating-campaign-key-visuals/references/delivery-and-provenance.md`: dimensions, aspect ratio, orthogonal provenance fields, and file handoff.
- `visual/generating-campaign-key-visuals/evals/cases.md`: regression scenarios.
- `README.md` and `visual/README.md`: library navigation.

### Task 1: Capture the failing baseline

**Files:**
- Create: `visual/generating-campaign-key-visuals/evals/cases.md`

- [ ] **Step 1: Record observed failure cases**

Include aspect-ratio drift, pseudo-text in blank cards, hierarchy collapse, native-versus-upscaled confusion, macOS privacy fallback, and font redistribution boundaries. Each case contains request, expected decision, forbidden outcome, and pass criteria.

- [ ] **Step 2: Verify the implementation does not yet exist**

Run:

```bash
test -f visual/generating-campaign-key-visuals/SKILL.md
```

Expected: exit status `1`.

### Task 2: Create the skill entrypoint

**Files:**
- Create: `visual/generating-campaign-key-visuals/SKILL.md`
- Create: `visual/generating-campaign-key-visuals/agents/openai.yaml`

- [ ] **Step 1: Write discriminating frontmatter**

Use:

```yaml
---
name: generating-campaign-key-visuals
description: Use when creating or refining campaign key visuals, event posters, e-commerce promotional artwork, or dense marketing heroes where composition hierarchy, embedded text, information cards, and delivery dimensions must remain controlled.
---
```

- [ ] **Step 2: Add the four-contract model and reference routing**

Keep the entrypoint concise. Route composition, typography, prompting, quality review, and delivery to the corresponding references.

- [ ] **Step 3: Add UI metadata**

Use display name `Campaign Key Visuals`, a 25–64 character short description, and a one-sentence default prompt that invokes `$generating-campaign-key-visuals`.

### Task 3: Write workflow and composition references

**Files:**
- Create: `visual/generating-campaign-key-visuals/references/workflow.md`
- Create: `visual/generating-campaign-key-visuals/references/composition-brief.md`

- [ ] **Step 1: Define the contract workflow**

Specify request normalization, contradiction handling, skeleton lock, generation, content QA, style QA, and delivery.

- [ ] **Step 2: Define the hierarchy skeleton**

Cover canvas, title, focal subject, motion path, foreground depth, supporting world, background context, information modules, and intentional negative space. State that object count alone is not composition.

### Task 4: Write typography and prompt references

**Files:**
- Create: `visual/generating-campaign-key-visuals/references/text-and-typography.md`
- Create: `visual/generating-campaign-key-visuals/references/prompt-template.md`

- [ ] **Step 1: Define text strategy**

Describe direct rendering for short inspectable text, post-composition for higher-risk copy, genuinely blank information cards, glyph verification, local-font preparation, and license boundaries.

- [ ] **Step 2: Create a structured prompt template**

Expose content, hierarchy, rendering, exact text, blank regions, and negative constraints as explicit slots. Do not include real brand copy.

### Task 5: Write QA and delivery references

**Files:**
- Create: `visual/generating-campaign-key-visuals/references/quality-gates.md`
- Create: `visual/generating-campaign-key-visuals/references/delivery-and-provenance.md`

- [ ] **Step 1: Define two-pass QA**

Pass one checks count, exact text, blank regions, forbidden marks, hierarchy, and ratio. Pass two checks palette, material, lighting, depth, density, and polish.

- [ ] **Step 2: Define transparent delivery language**

Require exact pixel dimensions, aspect ratio, format, source-raster dimensions, raster-upscale status, canvas/layout recomposition status, and typography-composition status. Preserve the originating render beside derived exports.

### Task 6: Update navigation

**Files:**
- Modify: `README.md`
- Modify: `visual/README.md`

- [ ] **Step 1: Add the skill to the repository overview**

List the skill under the visual category and summarize its composition, typography, and delivery focus.

- [ ] **Step 2: Replace the empty visual-category message**

Add a direct link to the skill while retaining return navigation.

### Task 7: Validate and publish

**Files:**
- Review all created and modified files.

- [ ] **Step 1: Run structural validation**

```bash
python ~/.codex/skills/.system/skill-creator/scripts/quick_validate.py visual/generating-campaign-key-visuals
```

Expected: validation succeeds.

- [ ] **Step 2: Run repository checks**

```bash
git diff --check
test -z "$(rg -l 'TBD|TODO|/Users/|TemporaryItems|codex-clipboard' visual/generating-campaign-key-visuals README.md visual/README.md || true)"
find visual/generating-campaign-key-visuals -type f -maxdepth 4 | sort
```

Expected: no whitespace errors, private paths, unfinished placeholders, copied transcripts, or unplanned files.

- [ ] **Step 3: Review against the design spec**

Check every scope item and public-release boundary in `docs/superpowers/specs/2026-11-09-generating-campaign-key-visuals-design.md` against the diff.

- [ ] **Step 4: Commit**

```bash
git add README.md visual docs
git commit -m "feat: add campaign key visual skill"
```

Expected: the validated branch contains a reviewable local commit without modifying `main`.
