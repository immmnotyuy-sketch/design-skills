# Generating Campaign Key Visuals Skill Design

## Goal

Publish a reusable visual-design skill for producing dense campaign key visuals, event posters, and e-commerce hero artwork whose composition, embedded text, information modules, and delivery claims remain controlled from brief through export.

## Scope

The first release covers:

- translating an object-heavy brief into a hierarchy and layout contract;
- separating fixed content from flexible visual treatment;
- deciding when text may be rendered directly and when it needs post-composition;
- preventing empty cards and decorative surfaces from acquiring pseudo-text;
- checking content before style;
- reporting actual aspect ratio, pixel dimensions, and native-versus-upscaled provenance;
- using local fonts without publishing unlicensed font binaries.

It does not prescribe one visual style, replace a professional layout application, promise perfect text from every image generator, redistribute fonts, or define print-production color management.

## Architecture

Use progressive disclosure:

```text
visual/generating-campaign-key-visuals/
├── SKILL.md
├── agents/openai.yaml
├── references/
│   ├── workflow.md
│   ├── composition-brief.md
│   ├── text-and-typography.md
│   ├── prompt-template.md
│   ├── quality-gates.md
│   └── delivery-and-provenance.md
└── evals/cases.md
```

`SKILL.md` routes work and preserves shared invariants. References separate composition, typography, prompting, review, and delivery so a request loads only the detail it needs.

## Core Model

Every campaign KV is expressed as four contracts:

1. **Content contract:** required objects, exact text, blank regions, forbidden marks, count, and order.
2. **Hierarchy contract:** title, focal subject, motion path, foreground depth, supporting world, background, and information modules.
3. **Rendering contract:** palette, material, lighting, style, density, and finish.
4. **Delivery contract:** aspect ratio, actual dimensions, file format, provenance, and whether resizing or recomposition occurred.

The rendering contract may change without silently changing the other three.

## Workflow

1. Normalize the request into the four contracts.
2. Resolve contradictions and mark unspecified copy as blank rather than inventing text.
3. Lock the composition skeleton before expanding decorative detail.
4. Select direct-render or post-composition text handling.
5. Build a structured generation brief.
6. Generate the artwork and inspect the actual output rather than trusting the prompt.
7. Run content QA before style QA.
8. Export and report exact dimensions, aspect ratio, and provenance.

## Non-Obvious Invariants

- Object count is not composition. Every dense brief needs a focal hierarchy and a motion path.
- A requested aspect ratio and the returned pixel ratio must be compared explicitly.
- A card with no supplied copy remains genuinely blank; placeholder lines, icons, and pseudo-text are not harmless decoration.
- One short title may be rendered directly only when exact glyphs can be inspected. Otherwise reserve the region and composite typography afterward.
- A file with a 4096-pixel long edge may be described as a 4096-pixel-long-edge export, but an upscale must not be described as native 4K.
- Installed fonts are not automatically licensed for commercial use or redistribution. Public repositories contain workflow and provenance notes, not font binaries.

## Evaluation Strategy

Behavioral cases cover:

- a 3:4 brief returning a 2:3 render;
- exact Chinese title requirements and blank information cards;
- dense object lists that lose title and subject hierarchy;
- 1024×1536 artwork resized to 2731×4096;
- local fonts under macOS privacy protection;
- fonts that are installed locally but have unclear public redistribution rights.

The skill passes when an agent preserves the content and hierarchy contracts, catches ratio and text drift, avoids invented copy, and reports delivery provenance without overstating quality.

## Public Release Boundary

Use anonymous or project-owned examples only. Do not include user artwork, chat transcripts, local absolute paths, private repository information, font binaries, or brand assets. Generic placeholder titles may demonstrate text handling without becoming reusable campaign copy.
