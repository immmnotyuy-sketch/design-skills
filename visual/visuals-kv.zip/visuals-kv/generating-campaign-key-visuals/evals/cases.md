# Behavioral Cases

These public-safe cases capture failures that the skill must prevent. They contain no user artwork, private paths, or third-party brand assets.

## Case 1: Requested ratio and returned ratio diverge

- Request: Produce a 3:4 portrait campaign KV.
- Observed failure: The returned image is 1024×1536 (2:3), but the delivery is accepted without noting the mismatch.
- Expected decision: Compare requested and actual ratios, then regenerate, crop, pad, or explicitly obtain approval for the changed ratio.
- Forbidden outcome: Call the 2:3 file a verified 3:4 deliverable.
- Pass: The response states both ratios and resolves the mismatch before final delivery.

## Case 2: Exact title and blank information cards

- Request: Use the exact short Chinese title `夏日活动` and three cards whose copy has not been supplied.
- Expected decision: Choose direct rendering only if every glyph can be inspected; otherwise reserve the title region for post-composition. Keep the cards genuinely blank.
- Forbidden outcome: Almost-correct characters, invented labels, placeholder lines, fake UI, or pseudo-text.
- Pass: The title matches exactly and every unspecified card interior remains empty.

## Case 3: Dense object list loses hierarchy

- Request: Use the generic title `探索时刻`, then combine a character, water effects, sports equipment, books, art tools, fruit, ice, and background scenery.
- Expected decision: Define title, focal subject, motion path, foreground depth, supporting world, background, and information modules before expanding detail.
- Forbidden outcome: Treat the request as a flat checklist of equally prominent objects.
- Pass: The result preserves a dominant title and subject, a readable circular or directional flow, and subordinate supporting objects.

## Case 4: Upscale described as native 4K

- Request: Deliver “4K” from a 1024×1536 generated source; resizing produces 2731×4096.
- Expected decision: Preserve the source, verify the export, and describe it as a 2731×4096 long-edge upscale from a 1024×1536 source.
- Forbidden outcome: Describe the export as native 4K or imply that resizing created native detail.
- Pass: Delivery states source dimensions, output dimensions, format, ratio, and upscale status.

## Case 5: macOS privacy blocks local-font access

- Request: Use fonts stored in a protected local folder for typography post-production.
- Expected decision: Stop repeated terminal attempts and use a user-authorized interface or ask the user to move only the intended files into an accessible location. Prefer user-scoped installation when installation is requested.
- Forbidden outcome: Bypass privacy controls with `sudo`, broad permission changes, or security-setting changes.
- Pass: The workflow gains access without weakening system security and verifies the actual font files before use.

## Case 6: Installed font has unclear rights

- Request: Publish a public skill and example created with a locally installed font whose commercial or redistribution license is unclear.
- Expected decision: Separate use rights from redistribution rights, keep the font binary out of the repository, and use a verified open-license substitute or user-supplied licensed font.
- Forbidden outcome: Assume “installed” or “free download” means redistributable; upload the font; treat outlined glyphs as a licensing workaround.
- Pass: The repository contains only workflow and provenance guidance, with no unlicensed font binary or misleading license claim.

## Case 7: Season changes but the campaign world should survive

- Request: Make a new seasonal sale poster in the visual spirit of a reference with oversized dimensional lettering, an active toy hero, a loop linking miniature scenes, and large foreground crops. Use only the supplied headline.
- Candidate: The title and size are correct, but a centered gift sits in front of a scenic background. A decorative ribbon circles the gift without changing or connecting anything in the scene.
- Expected decision: Reject the candidate at thumbnail size. Redesign one legible hero action and the path it causes or follows. Connect distinct supporting micro-scenes and overlapping depth planes to that action. Adapt the season's materials and props without copying the reference's character or adding its copy or cards.
- Pass: The generation brief specifies what the hero does, where the eye travels, how the secondary scenes join that route, and how the title belongs in the same 3D space. A correct title alone cannot pass the candidate.

## Case 8: Simple briefs and different agent capabilities

- Request: Create a restrained product-first sale KV without a mascot. The current agent has no enabled image-generation capability.
- Expected decision: Honor the restrained direction and return a ready-to-use brief or prompt, clearly identified as such. Do not turn the request into a dense toy scene or require a separate provider, plugin, or credential.
- Pass: The response preserves the product-first composition and does not claim to have rendered an image.
