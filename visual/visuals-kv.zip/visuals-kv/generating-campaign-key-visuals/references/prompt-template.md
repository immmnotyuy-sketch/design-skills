# Prompt Template

Use only slots supported by the brief. Keep exact text, intentionally blank regions, and forbidden elements explicit rather than burying them in style prose.

```markdown
Create a campaign key visual using these locked contracts.

CONTENT CONTRACT
- Required subjects and objects: [items]
- Exact count and order: [count/order]
- Exact copy in the production contract: [verbatim supplied copy, or "none"]
- Text strategy: [direct render / post-composition / no text]
- Blank regions: [regions that must contain no marks or content]
- Forbidden elements: [items, marks, pseudo-text, or additions to exclude]

HIERARCHY CONTRACT
- Reference transfer, if applicable: [retain visual relationships / redesign theme-specific content]
- Canvas and crop-safe area: [orientation/ratio/safe area]
- Title zone: [position/scale/dimensional treatment or reserved post-composition region]
- Focal subject: [subject/action/visible effect/dominance, where applicable]
- Motion path: [driver → entry → focal point → supporting world → exit]
- Foreground depth: [framing/overlaps/effects]
- Supporting world: [groups and their roles in the same scene]
- Background context: [setting/anchors/detail level]
- Information modules: [count/position/order/content state]
- Intentional negative space: [location/purpose]

RENDERING CONTRACT
- Palette: [colors/contrast]
- Material and texture: [treatment]
- Lighting: [direction/quality]
- Style and finish: [visual language]
- Density: [where dense/where restrained]

DELIVERY CONTRACT
- Requested aspect ratio: [ratio]
- Requested pixel dimensions: [width × height]
- File format: [format]
- Crop or resize rules: [allowed/not allowed]

TEXT INSTRUCTION
- Keep exactly one branch below and remove the other two before generation.
- Direct render: render exactly [verbatim supplied text] and no other text.
- Post-composition: render no text or glyph-like marks; reserve [zone] as a clean, unobstructed typography area. Apply [verbatim supplied text] only during post-production.
- No text: render no text or glyph-like marks anywhere.

BLANK REGIONS
- [region]: leave genuinely empty; no labels, lines, icons, fake UI, or pseudo-text

FORBIDDEN ELEMENTS
- [explicit negative constraints]
```

After generation, compare the actual image and metadata with every slot. Prompt inclusion is not proof of compliance.
