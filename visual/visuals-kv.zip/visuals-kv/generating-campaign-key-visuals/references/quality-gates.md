# Quality Gates

Review in two passes. A candidate that fails Pass 1 does not advance to style review.

## Pass 1: Content and structure

- Exact subject and object count matches the contract.
- Required elements and information modules follow the specified order.
- Every glyph, punctuation mark, specified line break, and reading sequence matches supplied text.
- Unspecified cards and reserved regions are genuinely blank, without placeholder lines, icons, fake UI, or pseudo-text.
- Unrequested or contract-forbidden marks, signatures, watermarks, added copy, and excluded objects are absent; required legal or attribution marks remain intact.
- Title, focal subject, motion path, depth layers, supporting world, background, and information modules preserve the locked hierarchy.
- Requested and actual aspect ratios are calculated and compared.
- Requested and actual pixel dimensions are read from the files and compared.

For reference-led work, compare the candidate and reference at thumbnail size. Judge the visual relationships selected for transfer, not whether the objects match literally.

- Can you read the headline and identify the dominant subject before the accents?
- If the scene calls for action, can you name what happens and trace the path through the hero into the supporting world? Is there a meaningful difference between foreground, hero plane, and background?
- Do the silhouette, scale contrast, overlaps, and relative density carry the intended energy? Reject a static product shot with detached decoration if the brief calls for a narrative campaign world, even when the title and file specs are correct.

Reject, regenerate, crop, pad, recompose, or obtain approval for any content, hierarchy, ratio, or dimension mismatch before proceeding.

## Pass 2: Rendering quality

- Palette and contrast support the intended reading order.
- Materials and textures are coherent at final viewing size.
- Lighting has a consistent direction, intensity, and effect on form.
- Foreground, subject, supporting world, and background produce readable depth.
- Density is intentional, with protected negative space and no accidental clutter.
- Edges, transitions, typography integration, and finish meet the required polish level.
- Objects remain structurally credible: no fused forms, broken anatomy, impossible joins, or accidental duplicates.

## Iteration stop-loss

If the reference's core relationships are missing, fix the composition skeleton first: the hero's action, path, and connected depth planes. More props, saturation, or effects cannot repair that failure. For localized defects, change one variable at a time. If the same defect recurs, switch strategies rather than piling on prompt clauses.
