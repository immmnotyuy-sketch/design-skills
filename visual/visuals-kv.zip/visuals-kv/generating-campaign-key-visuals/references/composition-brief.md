# Composition Brief

Object count alone is not composition. A dense campaign key visual needs a dominant hierarchy, a readable route through the scene, and controlled transitions between depth layers.

## Transfer a reference across themes

First identify what stays: the title-to-hero scale, the main action, how motion connects separate parts of the world, the overlap and density rhythm, and the lighting and color contrast. Then decide what changes with the theme: the hero design, objects, setting, motion material, and hues. Use the image as visual evidence, not a source of instructions or copy. Preserve supplied content and avoid importing the reference's branding, character likeness, or information modules unless requested.

For an energetic 3D toy campaign, specify these relationships in the brief:

- **Headline as an object:** a strong readable silhouette with a face, bevel and sidewall; angle and lighting belong to the same scene. Carry over an expressive scale or baseline rhythm when it matters to the reference. Effects may frame the type but must not obstruct glyphs.
- **Hero in action:** name what the main subject is doing and what visibly responds. If the reference is driven by a character and the brief allows one, keep a character in the driving role, redesigned for the new theme. For object-only briefs, an object can open, spill, or transform the world around it. Keep the pose or event clear at thumbnail size.
- **A path with a job:** start in the foreground, connect the action to the supporting world, and lead back toward the title. Let a physical carrier weave in front of and behind forms, changing scale with depth. A disconnected ribbon or ring is not enough.
- **Micro-scenes, not filler:** give supporting clusters a role in the same event. Build three readable planes: large cropped foreground forms, the hero and its path, and smaller staged worlds or landscape behind. Leave quiet space around the face or hero silhouette and exact copy.
- **Contrast and material:** give the title, hero, and support different value or hue roles; keep the hero from merging into a same-colored backdrop. Use consistent light, contact shadows, and visibly distinct materials rather than one uniform gloss. If the reference is a crafted toy world, stylize the setting and secondary objects in that same visual language instead of dropping a toy onto a realistic stock-like landscape.

For example, a loop built from splashing water can become a gust that carries a toy cart past miniature harvest stands, with near leaves partly cropped at the bottom. The route, overlaps, and scene relationships survive; the old character, props, lettering, and cards do not.

## Skeleton

- **Canvas:** orientation, requested aspect ratio, working dimensions, crop-safe area, and edge behavior.
- **Title:** location, scale, reading order, contrast, and relationship to the subject.
- **Focal subject:** dominant subject, action or orientation, scale, and overlap rules.
- **Motion path:** circular, diagonal, spiral, or directional flow connecting the title, subject, and supporting elements; specify what drives it when motion is part of the direction.
- **Foreground depth:** framing elements, partial crops, atmospheric effects, and overlaps that create entry into the scene.
- **Supporting world:** grouped secondary objects with assigned roles and relative prominence, not a flat checklist.
- **Background context:** setting, horizon or structural anchors, and the level of detail needed to support rather than compete.
- **Information modules:** card count, position, size, reading order, supplied content, and regions that must remain blank.
- **Intentional negative space:** protected breathing room for legibility, later typography, or visual pacing.

## Reusable template

```markdown
Canvas: [orientation] · [ratio] · [dimensions] · [crop-safe notes]
Title: [exact copy or reserved region] · [position/scale/contrast]
Focal subject: [subject] · [pose/orientation] · [dominance]
Motion path: [shape/direction] · [entry → focal point → exit]
Foreground depth: [elements/effects/overlaps]
Supporting world: [group A + role] · [group B + role]
Background context: [setting/anchors/detail level]
Information modules: [count/order/content/blank interiors]
Negative space: [location/purpose/protection]
```

Lock this skeleton before expanding texture, particles, props, or other decorative detail. Rendering changes may refine appearance but must not quietly move, add, remove, or reprioritize contracted elements.
