# Workflow

## 1. Normalize the request

Record the brief as four separate contracts:

- **Content:** required objects, exact text, genuinely blank regions, forbidden elements, count, and order.
- **Hierarchy:** title, focal subject, motion path, depth layers, supporting world, background, and information modules.
- **Rendering:** palette, material, lighting, style, density, and finish.
- **Delivery:** aspect ratio, pixel dimensions, file format, and required provenance.

Label every item as fixed, flexible, or unspecified. If adapting a reference, distinguish its transferable composition and rendering from theme-specific content. Do not invent copy or add unrelated decoration.

## 2. Resolve contradictions

Compare requirements before generating. Ask for a decision when fixed constraints conflict, such as an object count that cannot fit the requested canvas without breaking the named hierarchy. If a low-risk detail is unspecified, preserve the contracts and choose conservatively; never resolve ambiguity by fabricating text, marks, or deliverable claims.

## 3. Lock the skeleton

Define the canvas, title zone, focal subject, motion path, depth layers, supporting world, background context, information modules, and negative space. Keep this skeleton fixed while refining rendering. Use [composition-brief.md](composition-brief.md) for the reusable brief.

## 4. Choose a text strategy

Render text directly only when it is short and every glyph can be inspected. Otherwise reserve a clean region and composite typography afterward. Keep unspecified cards genuinely blank. See [text-and-typography.md](text-and-typography.md).

## 5. Assemble the prompt

Translate the four contracts into explicit slots. Separate exact text, blank regions, and forbidden elements from visual treatment so style changes cannot rewrite content. Use [prompt-template.md](prompt-template.md).

## 6. Generate and inspect

Generate against the locked skeleton using the user's chosen tool or the current agent's available image capability. If the user supplied a visual reference, describe what to transfer and what to replace; attach the reference only if the tool supports it. If image generation itself is unavailable, hand off the prompt without claiming an image was made. Inspect returned pixels and file metadata; the prompt is an instruction, not evidence that the output complies.

## 7. Run content QA

Check exact count, order, text, blank regions, forbidden marks, hierarchy, requested ratio, actual ratio, requested dimensions, and actual dimensions. Reject or repair content failures before considering style.

## 8. Run style QA

Only after content passes, evaluate palette, material, lighting, depth, density, polish, and object integrity. Change one variable per iteration; if the same failure repeats, switch strategy instead of accumulating prompt clauses. See [quality-gates.md](quality-gates.md).

## 9. Deliver transparently

Export the required format and verify the final file. Report exact output dimensions and ratio, source-raster dimensions, whether raster content was upscaled, whether the canvas or layout was recomposed, and whether typography was composed separately. Preserve the originating render and version derived files. See [delivery-and-provenance.md](delivery-and-provenance.md).
