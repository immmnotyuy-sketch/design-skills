---
name: generating-campaign-key-visuals
description: Use when creating or refining campaign key visuals, event posters, e-commerce promotional artwork, or dense marketing heroes where composition hierarchy, embedded text, information cards, and delivery dimensions must remain controlled.
---

# Generating Campaign Key Visuals

1. **Set the direction.** Lock required content and exact copy, the reading order and composition, the rendering style, and the requested delivery. If the user supplies a style reference or asks to carry forward an established look, identify the visual relationships that make it work before choosing new subjects or colors. Transfer those relationships, not the reference's artwork or copy.
2. **Make the scene work.** For energetic, dense 3D toy-style KVs, stage one readable action or event. Link it to the supporting world with a visible path and overlapping depth; treat the headline as a dimensional part of the scene. A centered product with decorative props is not a substitute for an active campaign world. Keep simpler or product-first briefs simple.
3. **Generate and check.** Use the current agent's available image capability or the user's chosen tool. If neither is available, deliver a ready-to-use prompt and say no image was rendered. No specific service, plugin, or key is required by this skill. Check the actual image for exact content and dimensions, then compare the reading order, action, depth, and finish against the intended direction before delivering it.

## References

- For a reference-led or dense scene: [composition brief](references/composition-brief.md).
- For multi-constraint production: [workflow](references/workflow.md) and [prompt template](references/prompt-template.md).
- For exact copy, blank cards, or fonts: [typography](references/text-and-typography.md).
- For candidate review and export: [quality gates](references/quality-gates.md) and [delivery checks](references/delivery-and-provenance.md).
